# FantaBot

Progetto di base per avvio rapido su Vercel.