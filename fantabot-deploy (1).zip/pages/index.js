
export default function Home() {
  return (
    <div style={{ textAlign: "center", marginTop: "5rem", fontFamily: "Arial" }}>
      <h1>FantaBot è online!</h1>
      <p>Benvenuto nel tuo assistente personale per il Fantacalcio.</p>
    </div>
  );
}
